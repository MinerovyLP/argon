package dev.lvstrng.argon.utils.rotation;


public record Rotation(double yaw, double pitch) {
}
